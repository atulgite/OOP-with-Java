package com.app.vehicles;
 import java.lang.*;
public class Vehicle {
	private int registrationNo;
	private String color;
	private double price;
	
	public Vehicle(int registrationNo, String color, double price) {
		super();
		this.registrationNo = registrationNo;
		this.color = color;
		this.price = price;
	}
	@Override
	public String toString()
	{
		return "Reg number: " +registrationNo+ " Color: " +color+ " Price: " +price;
		
	}
	@Override
	public boolean equals(Object veh) {
		return this.registrationNo==((Vehicle)veh).registrationNo;
	}
}
