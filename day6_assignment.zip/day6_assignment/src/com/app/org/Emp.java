package com.app.org;

public abstract class Emp 
{
	private int id; 
	private String name; 
	private String depId; 
	private double basic;
	
	public Emp(int id, String name, String deptId, double basic)
	{
		this.id=id;
		this.name=name;
		this.depId=deptId;
		this.basic=basic;
	}
	
	//get emp details -- override toString.
	@Override
	public String toString()
	{
		return "Id: " +id+ "\tName: " +name+ "\tDepartment Id: " +depId+ "\tBasic Salery: " +basic;
	}
	
	public abstract double computeNetSalary();

	public double getBasic()
	{
		return basic;
	}

}
