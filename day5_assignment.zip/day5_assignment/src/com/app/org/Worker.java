package com.app.org;

//2.3 Worker state  --id,name,basic,deptId,hoursWorked,hourlyRate
//Behaviour--- 
//1. get worker details -- :  override toString.
//2.  compute net salary (formula:  = basic+(hoursWorked*hourlyRate) --override computeNetSalary
//3. get hrlyRate of the worker  -- add a new method to return hourly rate of a worker.(getter)

public class Worker extends Emp
{
	private int hoursWorked;
	private int hourlyRate;
	
	public Worker(int id, String name, String deptId, double basic, int hoursWorked, int hourlyRate) 
	{
		super(id, name, deptId, basic);
		this.hoursWorked=hoursWorked;
		this.hourlyRate=hourlyRate;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+ "Hours worked: " +hoursWorked+ "hourrly rate: " +hourlyRate;
	}
	
	@Override
	public double computeNetSalary()
	{
		return getBasic()+(hoursWorked*hourlyRate);
	}
	
	public int getHourlyRate()
	{
		return hourlyRate;
	}
}
