package com.app.org;

//2.2 Mgr state  ---id,name,basic,deptId , perfmonceBonus
//Behaviour ----1. get mgr details :  override toString. 
//2. compute net salary (formula: basic+perfmonceBonus) -- override computeNetSalary
//3. get performance bonus. --add a new method to return bonus.(getter)

public class Mgr extends Emp 
{
	private int perfmonceBonus;

	public Mgr(int id, String name, String deptId, double basic, int perfmonceBonus) 
	{
		super(id, name, deptId, basic);
		this.perfmonceBonus=perfmonceBonus;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+ "Performance bonus: " +perfmonceBonus;
	}
	
	@Override
	public double computeNetSalary()
	{
		return getBasic()+perfmonceBonus;
	}

	public int getPerfmonceBonus() 
	{
		return perfmonceBonus;
	}
}
