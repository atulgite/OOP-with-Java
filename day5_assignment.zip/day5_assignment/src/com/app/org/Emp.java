package com.app.org;

public class Emp 
{
	private int id; 
	private String name; 
	private String depId; 
	private double basic;
	
	public Emp(int id, String name, String deptId, double basic)
	{
		this.id=id;
		this.name=name;
		this.depId=deptId;
		this.basic=basic;
	}
	
	//get emp details -- override toString.
	@Override
	public String toString()
	{
		return "Employee details Id: " +id+ "Name: " +name+ "Department Id: " +depId+ "Basic Salery: " +basic;
	}
	
	public double computeNetSalary()
	{
		return 0;
	}
	
	public double getBasic()
	{
		return basic;
	}

}
