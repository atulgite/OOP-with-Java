package com.app.tester;
import java.util.Scanner;

import com.app.org.Emp;
import com.app.org.Mgr;
import com.app.org.Worker;

public class TestOrganization 
{

//	2.4 Write TestOrganization in "tester" package.
//	Create suitable array to store organization details.
//
//	Provide following options. Run the application till "exit"
//
//	1. Hire Manager
//	2. Hire Worker  
//	3. Display information of all employees including net salary  using single for-each loop.
//	Display from the same for-each loop, performance bonus if it's a manager or if it's a worker , display hourly rate of the worker .
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Organization:");
		Emp[] employee=new Emp[sc.nextInt()];
		
		int counter=0;
		boolean flag=true;
		while(flag!=false)
		{
			System.out.println("Enter choice \n1. Hire Manager. \n2. Hire Worker. \n3. Display Details. \n10. Exit");
			
			switch(sc.nextInt())
			{
			case 1:
				if (counter>=0 && counter<employee.length)
				{
					System.out.println("Enter details of Manager:id name department_id basic_sal Bonus");
					employee[counter++]=new Mgr(sc.nextInt(), sc.next(), sc.next(), sc.nextDouble(), sc.nextInt());
				}
				else
					System.out.println("There is no space in organization");
				break;
				
			case 2:
				if (counter>=0 && counter<employee.length)
				{
					System.out.println("Enter details of Worker:Id Name Department_id Basic_sal Hours_Worked Hourly_Rate");
					employee[counter++]=new Worker(sc.nextInt(), sc.next(), sc.next(), sc.nextDouble(), sc.nextInt(), sc.nextInt());
				}
				else
					System.out.println("There is no space in organization");
				break;
				
			case 3:
				for(Emp e1:employee)
				{
					if(e1!=null)
					{
						System.out.println(e1.toString()+ " " +e1.computeNetSalary());
					}
					
					if(e1 instanceof Mgr)
					{
						System.out.println("Bonus: " +((Mgr) e1).getPerfmonceBonus());
					}
					if(e1 instanceof Worker)
					{
						System.out.println("Hourly Rate: " +((Worker) e1).getHourlyRate());
					}
				}
				
			case 10:
				flag=false;
				break;
			}
		}
	}

}
