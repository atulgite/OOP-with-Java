package utils;
import com.app.vehicles.*;
import custom_exception.*;
public class ValidationRules {
	// add static method to check duplicate vehicle
	public static void duplicateCheck(Vehicle[] veh, int registrationNo, String color) throws DuplicateVehicleFounded
	{
		Vehicle v1=new Vehicle(registrationNo, color);
		for (Vehicle v:veh){
			if (v!=null)
				if(v.equals(v1))
					throw new DuplicateVehicleFounded("Duplicate Vehicle Detected");	
		}
	}
}
