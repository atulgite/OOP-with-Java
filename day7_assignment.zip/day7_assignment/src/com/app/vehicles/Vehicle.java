package com.app.vehicles;
 import java.lang.*;
public class Vehicle {
	private int registrationNo;
	private String color;
	private double price;
	
	public Vehicle(int registrationNo, String color, double price) {
		this.registrationNo = registrationNo;
		this.color = color;
		this.price = price;
	}
	public Vehicle(int registrationNo, String color) {
		this.registrationNo=registrationNo;
		this.color = color;
	}
	@Override
	public String toString()
	{
		return "Reg number: " +registrationNo+ " Color: " +color+ " Price: " +price;
		
	}
	@Override
	public boolean equals(Object veh) {
		//Vehicle v=(Vehicle);
		return this.registrationNo==((Vehicle)veh).registrationNo && this.color.equals(((Vehicle)veh).color);
	}
}
