package tester;

import java.util.Scanner;
import com.app.vehicles.*;
public class TestVehicle {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter vehicle details: Registration number , Color , Price");
		Vehicle v1=new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
		System.out.println("Enter vehicle details: Registration number , Color , Price");
		Vehicle v2=new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
		
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v1.equals(v2)?"Vehicles are SAME":"Vehicles are DIFFERENT");
		
		sc.close();
	}

}
