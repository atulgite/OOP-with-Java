package tester;

import java.util.Scanner;
import com.app.vehicles.Vehicle;
import utils.ValidationRules;

public class VehicleShowroom {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);) {
			System.out.println("Enter Size of Show-room");
			Vehicle[] veh = new Vehicle[sc.nextInt()]; // new Vehicle[sc.nextInt(), sc.next(), sc.nextDouble())];
			boolean exit = true;
			int counter = 0;
			while (exit != false) {
				try {
					System.out.println("Enter choice \t1.Add a Vehicle \t2. Display all Vehicles \t3. Exit");
					switch (sc.nextInt()) {
					case 1:
						if (counter < veh.length) {
							
							System.out.println("Enter Vehicle details: Registration_Number Color");
							ValidationRules.duplicateCheck(veh, sc.nextInt(), sc.next());
							System.out.println("Enter Vehicle details: Registration_Number Color Price");
							veh[counter++] = new Vehicle(sc.nextInt(), sc.next(), sc.nextDouble());
							System.out.println("Vehicle added Successfully!!!!!!!!!!");
						}
						else {
							System.out.println("Showroom is full");
						}
						break;

					case 2:
						for (Vehicle v : veh) {
							if (v != null) {
								System.out.println(v);
							}
						}

					case 3:
						exit = false;
						break;
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}

			}
		} finally {
			System.out.println("main over");

		}
	}
}