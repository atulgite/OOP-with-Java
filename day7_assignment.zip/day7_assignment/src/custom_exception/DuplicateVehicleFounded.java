package custom_exception;

@SuppressWarnings("serial")
public class DuplicateVehicleFounded extends Exception {
	public DuplicateVehicleFounded(String msg)
	{
		super(msg);
	}
}
