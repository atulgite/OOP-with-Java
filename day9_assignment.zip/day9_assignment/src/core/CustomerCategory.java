package core;

public enum CustomerCategory {
	
	SILVER,GOLD,DIAMOND,PLATINUM;
	@Override
	public String toString()
	{
		return name().toLowerCase();
	}
	
}
