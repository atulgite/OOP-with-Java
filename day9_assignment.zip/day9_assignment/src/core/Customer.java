package core;

import java.text.SimpleDateFormat;
import java.util.Date;

//4.1 Customer : name(string),email(string),password(string),registrationAmount(double),dob(Date)
//Add/generate suitable constructor & toString
//Unique ID : email (where will you use this fact ?????????????????)
//Will you add any other data member in Customer class for parsing n formatting? HOW ?
public class Customer {
	private String name;
	private String emailId;
	private String password;
	private double regAmount;
	private Date dob;
	private CustomerCategory category;
	public static SimpleDateFormat sdf;

	static {
		sdf = new SimpleDateFormat("dd-MM-yyyy");
	}

	public Customer(String name, String emailId, String password, double regAmount, Date dob, CustomerCategory category) {
		super();
		this.name = name;
		this.emailId = emailId;
		this.password = password;
		this.regAmount = regAmount;
		this.dob = dob;
		this.category=category;
	}

	@Override
	public String toString() {
		return "Customer Details:- Name: " + name + ", Email Id: " + emailId + ", Password: " + password
				+ ", Registration Amount: " + regAmount + ", Date Of Birth: " + sdf.format(dob)+ "Customer Type "+category;
	}

	@Override
	public boolean equals(Object cust) {
		if (cust instanceof Customer) {
			Customer c1 = (Customer) cust;
			return this.emailId.equals(c1.emailId);
		} 
		else
			return false;
		// return this.emailId.equals(((Customer)cust).emailId);
	}
}
