package tester;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

import core.Customer;
import core.CustomerCategory;
import custom_exception.CustomerHandlingException;
import static utils.ValidationRules.*;

import static utils.ValidationRules.valdiateEmail;

//4.4 Create a simple tester : Tester1 (no while loop , no switch/case)
//MUST use try-with-resources to create scanner
//Prompt for customer details
//Validate customer details .
//Iff it's valid , display customer details , o.w display err mesg via catch block
public class TestCustomer {
	public static void main(String[] args) throws CustomerHandlingException, ParseException {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println(
					"Enter Customer Details: Name EamilId Password RegistrationAmount DateofBirth Customer_Category");
//			String name = sc.next();
//			String emailId = sc.next();
//			String password = sc.next();
//			double regAmount = sc.nextDouble();
//			String dob = sc.next();
//			String category = sc.next();

			Customer cust1 = new Customer(sc.next(), valdiateEmail(sc.next()), validatePassword(sc.next()),
					validateRegAmt(sc.nextDouble()), convertedDate(sc.next()), validateCategory(sc.next()));
			System.out.println(cust1);
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
	}

}
