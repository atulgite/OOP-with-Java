package utils;

import custom_exception.CustomerHandlingException;
import static core.Customer.sdf;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import core.CustomerCategory;
import core.CustomerCategory;

public class ValidationRules {
	public static final int MIN_LEN;
	public static final int MAX_LEN;
	public static Date threysholdDate;
	static {
		MIN_LEN = 4;
		MAX_LEN = 10;
		try {
			threysholdDate=sdf.parse("1-1-1990");
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public static String valdiateEmail(String emailId) throws CustomerHandlingException {
		if (emailId.contains("@") && emailId.contains(".com"))
			return emailId;
		else
			throw new CustomerHandlingException("Enter correct Email Id");
	}

	public static String validatePassword(String password) throws CustomerHandlingException {
		if (password.length() >= MIN_LEN && password.length() <= MAX_LEN)
			return password;
		throw new CustomerHandlingException("Enter password with 4 to 10 character");
	}

	public static Date convertedDate(String dob) throws ParseException,CustomerHandlingException {
		if ((sdf.parse(dob)).after(threysholdDate))
			throw new CustomerHandlingException("Date of Birth should be before 1-1-1990");
		return sdf.parse(dob);
	}
	public static double validateRegAmt(double regAmt) throws CustomerHandlingException
	{
		if ( regAmt % 500 == 0)
			return regAmt;
		throw new CustomerHandlingException("Registration amount should be multiple of 500");
	}
	public static CustomerCategory validateCategory(String category) throws CustomerHandlingException
	{
		try {
			return CustomerCategory.valueOf(category.toUpperCase());
		}
		catch (IllegalArgumentException e) {
			StringBuilder sb=new StringBuilder();
			sb.append("Enter valid customer category");
			throw new CustomerHandlingException("Enter valid details");
		}
	}
}
