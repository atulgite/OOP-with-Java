package core;

import java.text.SimpleDateFormat;
import java.util.Date;

//4.1 Customer : name(string),email(string),password(string),registrationAmount(double),dob(Date)
//Add/generate suitable constructor & toString
//Unique ID : email (where will you use this fact ?????????????????)
//Will you add any other data member in Customer class for parsing n formatting? HOW ?
public class Customer {
	private int custId;
	private String emailId;
	private String password;
	private double regAmount;
	private Date dob;
	public static SimpleDateFormat sdf;
	
	static {
		sdf=new SimpleDateFormat("dd-MM-yyyy");
	}

	public Customer(int custId, String emailId, String password, double regAmount, Date dob) {
		super();
		this.custId = custId;
		this.emailId = emailId;
		this.password = password;
		this.regAmount = regAmount;
		this.dob = dob;
	}
	@Override
	public String toString()
	{
		return "Customer Details:- Customer Id: " +custId+ ", Email Id: " +emailId+ ", Password: " +password+ ", Registration Amount: " +regAmount+ "Date Of Birth: "+sdf.format(dob);
	}
	@Override
	public boolean equals(Object cust)
	{
		Customer c1=(Customer)cust;
		return this.emailId.equals(c1.emailId);
		//return this.emailId.equals(((Customer)cust).emailId);
	}
}
