package utils;

import custom_exception.CustomerHandlingException;
import static core.Customer.sdf;

import java.text.ParseException;
import java.util.Date;

public class ValidationRules {
	public static String valdiateEmail(String emailId) throws CustomerHandlingException {
		if (emailId.contains("@") && emailId.contains(".com"))
			return emailId;
		else
			throw new CustomerHandlingException("Enter correct Email Id");
	}

	public static String validatePassword(String password) throws CustomerHandlingException {
		if (password.length() <= 10 && password.length() >= 4)
			return password;
		else
			throw new CustomerHandlingException("Enter password with 4 to 10 character");
	}
	
	public static Date convertedDate(String dob) throws ParseException
	{
		return sdf.parse(dob);
	}
}
