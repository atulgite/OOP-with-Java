package tester;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

import core.Customer;
import custom_exception.CustomerHandlingException;
import utils.ValidationRules;

import static utils.ValidationRules.valdiateEmail;

//4.4 Create a simple tester : Tester1 (no while loop , no switch/case)
//MUST use try-with-resources to create scanner
//Prompt for customer details
//Validate customer details .
//Iff it's valid , display customer details , o.w display err mesg via catch block
public class TestCustomer {
	public static void main(String[] args) throws CustomerHandlingException, ParseException
	{
		try (Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter Customer Details: CustomerId EamilId Password RegistrationAmount DateofBirth");
			int custId=sc.nextInt();
			String emailId=sc.next();
			String password=sc.next();
			double regAmount=sc.nextDouble();
			String dob=sc.next();
			valdiateEmail(emailId);
			ValidationRules.validatePassword(password);
			Customer cust1=new Customer(custId, emailId,password,regAmount,ValidationRules.convertedDate(dob));
			System.out.println();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
